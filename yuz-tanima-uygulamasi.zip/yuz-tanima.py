import tkinter as tk
from tkinter import filedialog, messagebox
from PIL import Image, ImageTk
import face_recognition
import cv2
import os
import pyttsx3
from datetime import datetime

class FaceRecognitionApp:
    def __init__(self, master):
        self.master = master
        self.master.title("Yüz Tanıma Sistemi")
        self.master.geometry("600x450")

        self.known_encodings = []
        self.known_names = []
        self.recognition_history = []  # Tanıma geçmişi burada tutulacak
        self.video_capture = None

        self.load_button = tk.Button(master, text="📤 Yüz Tanıt (Resim Yükle)", command=self.load_face)
        self.load_button.pack(pady=10)

        self.start_camera_button = tk.Button(master, text="🎥 Kamerayı Başlat", command=self.start_camera)
        self.start_camera_button.pack(pady=10)

        self.recognize_button = tk.Button(master, text="🧠 Yüz Tanı", command=self.recognize_face)
        self.recognize_button.pack(pady=10)

        self.exit_button = tk.Button(master, text="❌ Çıkış", command=self.quit_app)
        self.exit_button.pack(pady=10)

        self.video_label = tk.Label(master)
        self.video_label.pack()

        self.name_label = tk.Label(master, text="", font=("Arial", 14))
        self.name_label.pack(pady=10)

        # Geçmişi gösterecek olan Listbox
        self.history_label = tk.Label(master, text="Tanıma Geçmişi:", font=("Arial", 12))
        self.history_label.pack(pady=10)

        self.history_listbox = tk.Listbox(master, height=5, width=50)
        self.history_listbox.pack(pady=10)

        # Ses motorunu başlat
        self.engine = pyttsx3.init()
        self.engine.setProperty('rate', 150)  # Ses hızı
        self.engine.setProperty('volume', 1)  # Ses seviyesi (0.0 - 1.0)

    def load_face(self):
        file_path = filedialog.askopenfilename(filetypes=[("Resim Dosyaları", "*.jpg *.jpeg *.png")])
        if file_path:
            image = face_recognition.load_image_file(file_path)
            encodings = face_recognition.face_encodings(image)
            if encodings:
                self.known_encodings.append(encodings[0])
                name = os.path.splitext(os.path.basename(file_path))[0]
                self.known_names.append(name)
                messagebox.showinfo("Başarılı", f"{name} tanıtıldı.")
            else:
                messagebox.showerror("Hata", "Yüz bulunamadı.")

    def start_camera(self):
        self.video_capture = cv2.VideoCapture(0)

        if not self.video_capture.isOpened():
            messagebox.showerror("Kamera Hatası", "Kamera başlatılamadı.")
            return

        self.update_video_frame()

    def update_video_frame(self):
        if self.video_capture and self.video_capture.isOpened():
            ret, frame = self.video_capture.read()
            if ret:
                frame = cv2.flip(frame, 1)
                rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                img = Image.fromarray(rgb_frame)
                imgtk = ImageTk.PhotoImage(image=img)
                self.video_label.imgtk = imgtk
                self.video_label.configure(image=imgtk)
            self.master.after(10, self.update_video_frame)

    def recognize_face(self):
        if not self.known_encodings:
            messagebox.showwarning("Uyarı", "Lütfen en az bir yüz tanıt.")
            return
        if not self.video_capture or not self.video_capture.isOpened():
            messagebox.showwarning("Uyarı", "Kamera aktif değil.")
            return

        ret, frame = self.video_capture.read()
        if not ret:
            messagebox.showerror("Hata", "Kamera görüntüsü alınamadı.")
            return

        rgb_frame = frame[:, :, ::-1]
        face_locations = face_recognition.face_locations(rgb_frame)
        face_encodings = face_recognition.face_encodings(rgb_frame, face_locations)

        names_in_frame = []
        recognized_now = []  # O an tanınan kişiler

        for face_encoding in face_encodings:
            matches = face_recognition.compare_faces(self.known_encodings, face_encoding)
            name = "Bilinmeyen"

            if True in matches:
                matched_index = matches.index(True)
                name = self.known_names[matched_index]

            names_in_frame.append(name)
            recognized_now.append(name)

        if names_in_frame:
            self.name_label.config(text="Tanınan: " + ", ".join(names_in_frame))
            # Tanıma geçmişine kaydetme
            for name in recognized_now:
                timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                recognition_entry = f"{name} - {timestamp}"
                self.recognition_history.append(recognition_entry)
                self.history_listbox.insert(tk.END, recognition_entry)  # Listeye ekleme

            # Sesli yanıt işlemi: Tanıma tamamlandıktan sonra yapılmalı
            for name in recognized_now:
                self.engine.say(f"Merhaba, {name}!")
                self.engine.runAndWait()  # Sesli yanıt tamamlanana kadar bekle

        else:
            self.name_label.config(text="Sonuç: Yüz bulunamadı")

    def quit_app(self):
        if self.video_capture:
            self.video_capture.release()
        self.master.destroy()


if __name__ == "__main__":
    root = tk.Tk()
    app = FaceRecognitionApp(root)
    root.mainloop()
